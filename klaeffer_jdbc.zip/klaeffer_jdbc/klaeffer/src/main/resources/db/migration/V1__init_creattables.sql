create table klaeff(
    id serial primary key,
    githubid integer,
    username text,
    content varchar(300)
);

create table profil(
    id integer primary key,
    username text,
    avatar_url text
)