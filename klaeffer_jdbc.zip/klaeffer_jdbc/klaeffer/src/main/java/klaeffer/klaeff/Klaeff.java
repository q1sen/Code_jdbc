package klaeffer.klaeff;

import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.PersistenceCreator;
import org.springframework.data.relational.core.mapping.Column;

public class Klaeff implements Comparable<Klaeff>{


    @Id
    @Column("id")
    private final Long id;
    private final Long githubid;
    private final String username;
    private final String content;
    @PersistenceCreator
    public Klaeff(Long id,Long githubid, String username, String content){
        this.id=id;
        this.githubid = githubid;
        this.username=username;
        this.content=content;
    }

    @Override
    public int hashCode() {
        return id.hashCode();
    }

    @Override
    public int compareTo(Klaeff other) {
        return id.compareTo(other.id);
    }

    public Long getId() {
        return id;
    }

    public Long getGithubid() {
        return githubid;
    }

    public String getUsername() {
        return username;
    }

    public String getContent() {
        return content;
    }
}
