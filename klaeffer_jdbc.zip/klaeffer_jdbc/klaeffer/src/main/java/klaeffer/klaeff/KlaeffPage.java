package klaeffer.klaeff;

import java.util.Collections;
import java.util.List;

public record KlaeffPage(List<Klaeff> klaeffs, boolean more) {
}
