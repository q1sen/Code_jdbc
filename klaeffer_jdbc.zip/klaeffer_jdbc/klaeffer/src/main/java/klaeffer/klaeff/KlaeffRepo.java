package klaeffer.klaeff;

import org.springframework.data.repository.CrudRepository;

import java.util.LinkedList;
import java.util.List;

public interface KlaeffRepo extends CrudRepository<Klaeff,Integer> {
    List<Klaeff> findAll();
}
