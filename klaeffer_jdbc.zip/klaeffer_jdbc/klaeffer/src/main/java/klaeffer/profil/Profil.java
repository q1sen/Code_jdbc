package klaeffer.profil;

import org.springframework.data.annotation.Id;
import org.springframework.data.domain.Persistable;
import org.springframework.data.relational.core.mapping.Column;

public class Profil implements Persistable{


    @Id
    @Column("id")
    private final Long id;
    private String username;
    private String avatar_url;
    public static Boolean isnew;
    public Profil(Long id, String username, String avatar_url){
        this.id = id;
        this.username=username;
        this.avatar_url=avatar_url;
    }

    public Long getId() {
        return id;
    }

    @Override
    public boolean isNew() {
        return isnew;
    }


    public String getUsername() {
        return username;
    }

    public String getAvatar_url() {
        return avatar_url;
    }
}
