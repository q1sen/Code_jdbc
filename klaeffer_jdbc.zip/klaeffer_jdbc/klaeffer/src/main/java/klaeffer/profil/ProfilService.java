package klaeffer.profil;

import org.springframework.stereotype.Service;

@Service
public class ProfilService {
    private ProfilRepo profilRepo;

    public ProfilService(ProfilRepo profilRepo) {
        this.profilRepo = profilRepo;
    }

    public void addProfil(Profil profil){
        if (profilRepo.existsById(profil.getId())){
            Profil.isnew=false;
            profilRepo.save(profil);
        }else{
            Profil.isnew=true;
            profilRepo.save(profil);
        }

    }

    public Profil getProfil(Long id){
        return profilRepo.findById(id).get();
    }
}
