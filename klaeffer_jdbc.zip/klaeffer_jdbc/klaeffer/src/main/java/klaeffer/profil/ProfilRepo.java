package klaeffer.profil;

import org.springframework.data.repository.CrudRepository;

import java.util.LinkedList;
import java.util.List;
import java.util.Optional;

public interface ProfilRepo extends CrudRepository<Profil,Long> {
    LinkedList<Profil> findAll();
}
