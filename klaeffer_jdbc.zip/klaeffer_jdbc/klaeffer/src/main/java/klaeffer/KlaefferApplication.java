package klaeffer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KlaefferApplication {

  public static void main(String[] args) {
    SpringApplication.run(KlaefferApplication.class, args);
  }

}
